import { Router, type IRouter } from "express";
import { eq, asc } from "drizzle-orm";
import { db, leaderboardTable } from "@workspace/db";
import {
  AddLeaderboardEntryBody,
  UpdateLeaderboardEntryParams,
  UpdateLeaderboardEntryBody,
  DeleteLeaderboardEntryParams,
  SyncPlayerStatsParams,
} from "@workspace/api-zod";

const router: IRouter = Router();

const HOPLEX_BASE = "https://api.hoplex.xyz/public-assets";

interface HoplexStats {
  kills?: number;
  deaths?: number;
  wins?: number;
  losses?: number;
  gamesPlayed?: number;
  level?: number;
  winStreak?: number;
  highestKillstreak?: number;
  playtime?: number;
}

interface HoplexProfileResponse {
  success?: boolean;
  error?: string;
  user?: { displayName?: string; id?: number; username?: string };
  profile?: {
    stats?: HoplexStats;
  };
}

interface HoplexUserResponse {
  user?: { displayName?: string; id?: number; username?: string };
  assets?: { avatar?: string; head?: string };
}

function computeKdr(kills: number | null | undefined, deaths: number | null | undefined): number | null {
  if (kills == null) return null;
  if (!deaths) return kills;
  return Math.round((kills / deaths) * 100) / 100;
}

function computeScore(stats: HoplexStats): number {
  const wins = stats.wins ?? 0;
  const kills = stats.kills ?? 0;
  const deaths = stats.deaths ?? 0;
  const losses = stats.losses ?? 0;
  const level = stats.level ?? 0;
  const gamesPlayed = stats.gamesPlayed ?? 0;
  const highestKillstreak = stats.highestKillstreak ?? 0;
  const winStreak = stats.winStreak ?? 0;

  // True KDR — if no deaths, use raw kills as KDR
  const kdr = deaths > 0 ? kills / deaths : kills;

  // Win rate as 0–1 (requires at least 5 games to matter)
  const winRate = gamesPlayed >= 5 ? wins / gamesPlayed : 0;

  // Overall skill score:
  // Dominant: wins, level, kills, KDR (all weighted heavily)
  // Minor positive: win streak (counts but doesn't dominate)
  // Penalties: losses and deaths drag your score down
  return (wins * 1.5) + (level * 8) + (kills * 0.4) + (kdr * 25) + (winStreak * 0.3) - (losses * 2) - (deaths * 0.5);
}

async function fetchHoplexStats(username: string): Promise<{
  displayName: string;
  robloxId: string | null;
  avatarUrl: string | null;
  stats: HoplexStats;
} | null> {
  try {
    const profileRes = await fetch(`${HOPLEX_BASE}/v1/users/${encodeURIComponent(username)}/profile`);
    if (!profileRes.ok) return null;
    const profileData = await profileRes.json() as HoplexProfileResponse;
    if (profileData.success === false || !profileData.profile) return null;

    const stats: HoplexStats = profileData.profile.stats ?? {};
    const displayName = profileData.user?.displayName ?? username;
    const robloxId = profileData.user?.id != null ? String(profileData.user.id) : null;

    // Use the stable redirect URL — browser always fetches the current image, never expires
    const avatarUrl = `${HOPLEX_BASE}/v1/users/${encodeURIComponent(username)}/avatar?size=420x420&format=png&redirect=1`;

    return { displayName, robloxId, avatarUrl, stats };
  } catch {
    return null;
  }
}

async function recomputeRanks(): Promise<void> {
  const entries = await db.select().from(leaderboardTable);
  const sorted = [...entries].sort((a, b) => (b.score ?? 0) - (a.score ?? 0));
  await Promise.all(
    sorted.map((entry, index) =>
      db.update(leaderboardTable).set({ rank: index + 1 }).where(eq(leaderboardTable.id, entry.id))
    )
  );
}

router.get("/v1/leaderboard", async (_req, res): Promise<void> => {
  const entries = await db.select().from(leaderboardTable).orderBy(asc(leaderboardTable.rank));
  res.json(entries);
});

router.post("/v1/leaderboard", async (req, res): Promise<void> => {
  const parsed = AddLeaderboardEntryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { username, note } = parsed.data;

  const existing = await db.select().from(leaderboardTable).where(eq(leaderboardTable.username, username));
  if (existing.length > 0) {
    res.status(409).json({ error: "Player already on leaderboard" });
    return;
  }

  const hoplexData = await fetchHoplexStats(username);
  if (!hoplexData) {
    res.status(404).json({ error: "Player not found on Hoplex. Make sure they have played at least one game." });
    return;
  }

  const { displayName, robloxId, avatarUrl, stats } = hoplexData;
  const kdr = computeKdr(stats.kills, stats.deaths);
  const score = computeScore(stats);

  const [entry] = await db
    .insert(leaderboardTable)
    .values({
      username,
      displayName,
      robloxId,
      avatarUrl,
      note: note ?? null,
      kills: stats.kills ?? null,
      deaths: stats.deaths ?? null,
      wins: stats.wins ?? null,
      losses: stats.losses ?? null,
      kdr,
      level: stats.level ?? null,
      gamesPlayed: stats.gamesPlayed ?? null,
      winStreak: stats.winStreak ?? null,
      highestKillstreak: stats.highestKillstreak ?? null,
      playtime: stats.playtime ?? null,
      score,
      rank: 0,
      lastSyncedAt: new Date(),
    })
    .returning();

  await recomputeRanks();

  const [updated] = await db.select().from(leaderboardTable).where(eq(leaderboardTable.id, entry.id));
  res.status(201).json(updated);
});

router.post("/v1/leaderboard/sync", async (_req, res): Promise<void> => {
  const entries = await db.select().from(leaderboardTable);

  await Promise.all(
    entries.map(async (entry) => {
      const hoplexData = await fetchHoplexStats(entry.username);
      if (!hoplexData) return;
      const { displayName, robloxId, avatarUrl, stats } = hoplexData;
      const kdr = computeKdr(stats.kills, stats.deaths);
      const score = computeScore(stats);
      await db.update(leaderboardTable).set({
        displayName,
        robloxId,
        avatarUrl,
        kills: stats.kills ?? null,
        deaths: stats.deaths ?? null,
        wins: stats.wins ?? null,
        losses: stats.losses ?? null,
        kdr,
        level: stats.level ?? null,
        gamesPlayed: stats.gamesPlayed ?? null,
        winStreak: stats.winStreak ?? null,
        highestKillstreak: stats.highestKillstreak ?? null,
        playtime: stats.playtime ?? null,
        score,
        lastSyncedAt: new Date(),
      }).where(eq(leaderboardTable.id, entry.id));
    })
  );

  await recomputeRanks();

  const updated = await db.select().from(leaderboardTable).orderBy(asc(leaderboardTable.rank));
  res.json(updated);
});

router.get("/v1/leaderboard/stats", async (_req, res): Promise<void> => {
  const entries = await db.select().from(leaderboardTable).orderBy(asc(leaderboardTable.rank));

  const totalPlayers = entries.length;
  const topPlayer = entries.length > 0 ? entries[0].displayName : null;

  const entriesWithKdr = entries.filter((e) => e.kdr != null);
  const avgKdr =
    entriesWithKdr.length > 0
      ? Math.round((entriesWithKdr.reduce((sum, e) => sum + (e.kdr ?? 0), 0) / entriesWithKdr.length) * 100) / 100
      : null;

  const totalKills = entries.reduce((sum, e) => sum + (e.kills ?? 0), 0);
  const totalWins = entries.reduce((sum, e) => sum + (e.wins ?? 0), 0);

  res.json({ totalPlayers, topPlayer, avgKdr, totalKills, totalWins });
});

router.patch("/v1/leaderboard/:id", async (req, res): Promise<void> => {
  const params = UpdateLeaderboardEntryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateLeaderboardEntryBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [updated] = await db
    .update(leaderboardTable)
    .set({ note: parsed.data.note })
    .where(eq(leaderboardTable.id, params.data.id))
    .returning();

  if (!updated) {
    res.status(404).json({ error: "Entry not found" });
    return;
  }

  res.json(updated);
});

router.delete("/v1/leaderboard/:id", async (req, res): Promise<void> => {
  const params = DeleteLeaderboardEntryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [deleted] = await db
    .delete(leaderboardTable)
    .where(eq(leaderboardTable.id, params.data.id))
    .returning();

  if (!deleted) {
    res.status(404).json({ error: "Entry not found" });
    return;
  }

  await recomputeRanks();
  res.sendStatus(204);
});

router.post("/v1/leaderboard/:id/sync", async (req, res): Promise<void> => {
  const params = SyncPlayerStatsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [entry] = await db.select().from(leaderboardTable).where(eq(leaderboardTable.id, params.data.id));
  if (!entry) {
    res.status(404).json({ error: "Entry not found" });
    return;
  }

  const hoplexData = await fetchHoplexStats(entry.username);
  if (hoplexData) {
    const { displayName, robloxId, avatarUrl, stats } = hoplexData;
    const kdr = computeKdr(stats.kills, stats.deaths);
    const score = computeScore(stats);
    await db.update(leaderboardTable).set({
      displayName,
      robloxId,
      avatarUrl,
      kills: stats.kills ?? null,
      deaths: stats.deaths ?? null,
      wins: stats.wins ?? null,
      losses: stats.losses ?? null,
      kdr,
      level: stats.level ?? null,
      gamesPlayed: stats.gamesPlayed ?? null,
      winStreak: stats.winStreak ?? null,
      highestKillstreak: stats.highestKillstreak ?? null,
      playtime: stats.playtime ?? null,
      score,
      lastSyncedAt: new Date(),
    }).where(eq(leaderboardTable.id, params.data.id));
  }

  await recomputeRanks();

  const updated = await db.select().from(leaderboardTable).orderBy(asc(leaderboardTable.rank));
  res.json(updated);
});

export default router;
