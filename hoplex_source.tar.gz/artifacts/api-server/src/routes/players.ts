import { Router, type IRouter } from "express";
import { ResolvePlayerQueryParams } from "@workspace/api-zod";

const router: IRouter = Router();

const HOPLEX_BASE = "https://api.hoplex.xyz/public-assets";

interface HoplexProfileResponse {
  success?: boolean;
  error?: string;
  user?: { displayName?: string; id?: number; username?: string };
  profile?: {
    stats?: {
      kills?: number;
      deaths?: number;
      wins?: number;
      losses?: number;
      gamesPlayed?: number;
      level?: number;
      winStreak?: number;
      highestKillstreak?: number;
      playtime?: number;
    };
  };
}

interface HoplexUserResponse {
  user?: { displayName?: string; id?: number; username?: string };
  assets?: { avatar?: string; head?: string };
}

router.get("/v1/players/resolve", async (req, res): Promise<void> => {
  const parsed = ResolvePlayerQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: "username query parameter is required" });
    return;
  }

  const { username } = parsed.data;

  const profileRes = await fetch(`${HOPLEX_BASE}/v1/users/${encodeURIComponent(username)}/profile`);
  if (!profileRes.ok) {
    res.status(404).json({ error: "Player not found on Hoplex" });
    return;
  }

  const profileData = await profileRes.json() as HoplexProfileResponse;
  if (profileData.success === false || !profileData.profile) {
    res.status(404).json({ error: profileData.error ?? "Player not found on Hoplex. Make sure they have played at least one game." });
    return;
  }

  const stats = profileData.profile.stats ?? {};
  const displayName = profileData.user?.displayName ?? username;
  const robloxId = profileData.user?.id != null ? String(profileData.user.id) : null;

  // Use stable redirect URLs — always return the current image, no expiry
  const avatarUrl = `${HOPLEX_BASE}/v1/users/${encodeURIComponent(username)}/avatar?size=420x420&format=png&redirect=1`;
  const headUrl = `${HOPLEX_BASE}/v1/users/${encodeURIComponent(username)}/head?size=420x420&format=png&redirect=1`;

  const kills = stats.kills ?? null;
  const deaths = stats.deaths ?? null;
  const kdr = kills != null && deaths != null && deaths > 0 ? Math.round((kills / deaths) * 100) / 100 : kills;

  res.json({
    username,
    displayName,
    robloxId,
    avatarUrl,
    headUrl,
    kills,
    deaths,
    wins: stats.wins ?? null,
    losses: stats.losses ?? null,
    kdr,
    level: stats.level ?? null,
    gamesPlayed: stats.gamesPlayed ?? null,
    winStreak: stats.winStreak ?? null,
    highestKillstreak: stats.highestKillstreak ?? null,
  });
});

export default router;
