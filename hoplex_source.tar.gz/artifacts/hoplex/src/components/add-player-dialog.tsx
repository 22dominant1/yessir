import { useState } from "react";
import { useResolvePlayer, useAddLeaderboardEntry, getGetLeaderboardQueryKey, getGetLeaderboardStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { UserPlus, Search, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function AddPlayerDialog() {
  const [open, setOpen] = useState(false);
  const [username, setUsername] = useState("");
  const [searchTriggered, setSearchTriggered] = useState(false);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: profile, isLoading: isResolving, error: resolveError } = useResolvePlayer(
    { username }, 
    { query: { enabled: searchTriggered && !!username, retry: false } }
  );

  const addMutation = useAddLeaderboardEntry();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      setSearchTriggered(true);
    }
  };

  const handleAdd = () => {
    if (!profile) return;
    
    addMutation.mutate(
      { data: { username: profile.username } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetLeaderboardStatsQueryKey() });
          setOpen(false);
          setUsername("");
          setSearchTriggered(false);
          toast({
            title: "Player Recruited",
            description: `${profile.displayName} has joined the war.`,
          });
        },
        onError: (err) => {
          toast({
            variant: "destructive",
            title: "Error",
            description: err.error || "Failed to add player.",
          });
        }
      }
    );
  };

  const handleOpenChange = (newOpen: boolean) => {
    setOpen(newOpen);
    if (!newOpen) {
      setUsername("");
      setSearchTriggered(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        <Button className="rounded-none font-sans text-lg tracking-wide gap-2">
          <UserPlus className="h-4 w-4" />
          Recruit Player
        </Button>
      </DialogTrigger>
      <DialogContent className="rounded-none bg-card border-border sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-sans text-3xl text-foreground uppercase tracking-widest border-b border-border pb-2">
            New Warrior
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-6 py-4">
          <form onSubmit={handleSearch} className="flex gap-2">
            <Input 
              placeholder="Roblox Username..."
              value={username}
              onChange={(e) => {
                setUsername(e.target.value);
                setSearchTriggered(false);
              }}
              className="rounded-none border-border bg-background"
            />
            <Button type="submit" variant="secondary" className="rounded-none border border-border" disabled={!username || isResolving}>
              {isResolving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            </Button>
          </form>

          {resolveError && (
            <div className="text-sm text-destructive border border-destructive/50 bg-destructive/10 p-3">
              {(resolveError as any).error || "Could not resolve Roblox profile."}
            </div>
          )}

          {profile && !isResolving && !resolveError && (
            <div className="flex flex-col items-center gap-4 border border-primary/30 p-6 bg-background">
              <Avatar className="h-24 w-24 border-2 border-primary rounded-none">
                <AvatarImage src={profile.headUrl || profile.avatarUrl || undefined} alt={profile.displayName} />
                <AvatarFallback className="bg-muted text-muted-foreground rounded-none text-2xl font-sans">
                  {profile.displayName.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="text-center w-full">
                <div className="text-2xl font-sans font-bold text-foreground">{profile.displayName}</div>
                <div className="text-xs text-muted-foreground uppercase mb-4">@{profile.username}</div>
                
                <div className="grid grid-cols-3 gap-2 text-xs mb-4 p-2 bg-card border border-border">
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">LVL</span>
                    <span className="font-bold text-primary text-base">{profile.level ?? "-"}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">K</span>
                    <span className="font-bold text-base">{profile.kills ?? 0}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">D</span>
                    <span className="font-bold text-base">{profile.deaths ?? 0}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">W</span>
                    <span className="font-bold text-base">{profile.wins ?? 0}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">L</span>
                    <span className="font-bold text-base">{profile.losses ?? 0}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-muted-foreground">KDR</span>
                    <span className="font-bold text-base">{profile.kdr?.toFixed(2) ?? "0.00"}</span>
                  </div>
                </div>
              </div>
              
              <Button 
                onClick={handleAdd} 
                disabled={addMutation.isPending}
                className="w-full rounded-none font-sans text-xl"
              >
                {addMutation.isPending ? "Adding..." : "Confirm & Add"}
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}