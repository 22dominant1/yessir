import { type LeaderboardEntry, useDeleteLeaderboardEntry, useSyncPlayerStats, getGetLeaderboardQueryKey, getGetLeaderboardStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { EditPlayerDialog } from "@/components/edit-player-dialog";
import { Trash2, RefreshCw } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { formatDistanceToNow } from "date-fns";

export function AdminPlayerRow({ player }: { player: LeaderboardEntry }) {
  const queryClient = useQueryClient();
  const deleteMutation = useDeleteLeaderboardEntry();
  const syncMutation = useSyncPlayerStats();
  const { toast } = useToast();

  const handleDelete = () => {
    deleteMutation.mutate({ id: player.id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetLeaderboardStatsQueryKey() });
      }
    });
  };

  const handleSync = () => {
    syncMutation.mutate({ id: player.id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetLeaderboardStatsQueryKey() });
        toast({ title: "Stats synced", description: `${player.displayName}'s stats have been updated.` });
      },
      onError: () => {
        toast({ variant: "destructive", title: "Sync failed", description: "Failed to sync stats." });
      }
    });
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center p-3 bg-card border border-border">
      <div className="col-span-1 text-center border-r border-border/50">
        <span className="text-xl font-sans font-bold text-muted-foreground">#{player.rank}</span>
      </div>

      <div className="col-span-3 flex items-center gap-3">
        <Avatar className="h-10 w-10 border border-border rounded-none">
          <AvatarImage src={player.avatarUrl || undefined} alt={player.displayName} />
          <AvatarFallback className="bg-muted text-muted-foreground font-sans font-bold rounded-none">
            {player.displayName.substring(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex flex-col">
          <span className="text-lg font-sans font-bold text-foreground leading-none">{player.displayName}</span>
          {player.robloxId && (
            <span className="text-[10px] text-muted-foreground uppercase">@{player.username}</span>
          )}
        </div>
      </div>

      <div className="col-span-6 grid grid-cols-4 sm:grid-cols-8 gap-1 text-sm border-x border-border/50 px-2">
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-muted-foreground">LVL</span>
          <span className="font-bold text-primary">{player.level ?? "-"}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-muted-foreground">K</span>
          <span className="font-bold">{player.kills ?? 0}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-muted-foreground">D</span>
          <span className="font-bold">{player.deaths ?? 0}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-muted-foreground">W</span>
          <span className="font-bold">{player.wins ?? 0}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-muted-foreground">L</span>
          <span className="font-bold">{player.losses ?? 0}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-muted-foreground">KDR</span>
          <span className="font-bold">{player.kdr?.toFixed(2) ?? "0.00"}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-muted-foreground">W/S</span>
          <span className="font-bold">{player.winStreak ?? 0}</span>
        </div>
        <div className="flex flex-col items-center">
          <span className="text-[10px] text-muted-foreground">HKS</span>
          <span className="font-bold">{player.highestKillstreak ?? 0}</span>
        </div>
      </div>

      <div className="col-span-2 flex flex-col sm:flex-row items-center justify-end gap-2 pr-2">
        <div className="text-[9px] text-muted-foreground/70 hidden lg:block mr-2 text-right">
          {player.lastSyncedAt ? formatDistanceToNow(new Date(player.lastSyncedAt), { addSuffix: true }) : 'Never synced'}
        </div>
        <Button 
          variant="outline" 
          size="icon" 
          className="h-8 w-8 rounded-none border-border hover:border-primary hover:text-primary"
          onClick={handleSync}
          disabled={syncMutation.isPending}
        >
          <RefreshCw className={`h-4 w-4 ${syncMutation.isPending ? "animate-spin" : ""}`} />
        </Button>
        <EditPlayerDialog player={player} />
        
        <AlertDialog>
          <AlertDialogTrigger asChild>
            <Button variant="outline" size="icon" className="h-8 w-8 rounded-none border-border hover:bg-destructive hover:text-destructive-foreground hover:border-destructive">
              <Trash2 className="h-4 w-4" />
            </Button>
          </AlertDialogTrigger>
          <AlertDialogContent className="rounded-none border-border bg-card">
            <AlertDialogHeader>
              <AlertDialogTitle className="font-sans text-2xl uppercase">Delete Player</AlertDialogTitle>
              <AlertDialogDescription>
                Are you sure you want to completely obliterate <strong className="text-foreground">{player.displayName}</strong> from the leaderboard? This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="rounded-none">Cancel</AlertDialogCancel>
              <AlertDialogAction 
                className="rounded-none bg-destructive text-destructive-foreground hover:bg-destructive/90"
                onClick={handleDelete}
                disabled={deleteMutation.isPending}
              >
                {deleteMutation.isPending ? "Erasing..." : "Obliterate"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  );
}