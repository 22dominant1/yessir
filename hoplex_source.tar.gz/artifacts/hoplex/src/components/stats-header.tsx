import { type LeaderboardStats } from "@workspace/api-client-react";

export function StatsHeader({ stats }: { stats: LeaderboardStats }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 bg-card border border-border p-6 shadow-[0_0_30px_rgba(0,0,0,0.5)]">
      <div className="flex flex-col gap-1 border-r border-border/50 pr-4">
        <span className="text-xs text-muted-foreground tracking-widest">Total Kills</span>
        <span className="text-3xl font-sans font-bold text-foreground">
          {stats.totalKills ?? 0}
        </span>
      </div>
      
      <div className="flex flex-col gap-1 md:border-r border-border/50 px-4">
        <span className="text-xs text-muted-foreground tracking-widest">Total Wins</span>
        <span className="text-3xl font-sans font-bold text-foreground">
          {stats.totalWins ?? 0}
        </span>
      </div>
      
      <div className="flex flex-col gap-1 md:border-r border-border/50 px-4">
        <span className="text-xs text-muted-foreground tracking-widest">Top Player</span>
        <span className="text-3xl font-sans font-bold text-primary truncate">
          {stats.topPlayer || "N/A"}
        </span>
      </div>
      
      <div className="flex flex-col gap-1 border-r border-border/50 px-4">
        <span className="text-xs text-muted-foreground tracking-widest">Avg KDR</span>
        <span className="text-3xl font-sans font-bold text-foreground">
          {stats.avgKdr ? stats.avgKdr.toFixed(2) : "0.00"}
        </span>
      </div>
      
      <div className="flex flex-col gap-1 pl-4">
        <span className="text-xs text-muted-foreground tracking-widest">Active Warriors</span>
        <span className="text-3xl font-sans font-bold text-foreground">
          {stats.totalPlayers}
        </span>
      </div>
    </div>
  );
}