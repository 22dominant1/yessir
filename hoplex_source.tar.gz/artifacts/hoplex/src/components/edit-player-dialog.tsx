import { useState } from "react";
import { type LeaderboardEntry, useUpdateLeaderboardEntry, getGetLeaderboardQueryKey, getGetLeaderboardStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Edit2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function EditPlayerDialog({ player }: { player: LeaderboardEntry }) {
  const [open, setOpen] = useState(false);
  const [note, setNote] = useState(player.note || "");
  
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const updateMutation = useUpdateLeaderboardEntry();

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    
    updateMutation.mutate(
      { 
        id: player.id,
        data: {
          note: note.trim() || null,
        }
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
          queryClient.invalidateQueries({ queryKey: getGetLeaderboardStatsQueryKey() });
          setOpen(false);
          toast({
            title: "Note Updated",
            description: `${player.displayName}'s note has been modified.`,
          });
        },
        onError: (err) => {
          toast({
            variant: "destructive",
            title: "Error",
            description: err.error || "Failed to update note.",
          });
        }
      }
    );
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="icon" className="h-8 w-8 rounded-none border-border hover:border-primary hover:text-primary">
          <Edit2 className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="rounded-none bg-card border-border sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="font-sans text-2xl text-foreground uppercase tracking-widest border-b border-border pb-2">
            Edit Note: <span className="text-primary">{player.displayName}</span>
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSave} className="flex flex-col gap-6 py-4">
          <div className="flex flex-col gap-2">
            <Label htmlFor="note" className="text-xs uppercase text-muted-foreground">Admin Note (Optional)</Label>
            <Textarea 
              id="note" 
              placeholder="E.g. 'Suspected hacker', 'Tournament Winner'"
              value={note} 
              onChange={(e) => setNote(e.target.value)}
              className="rounded-none resize-none h-24 bg-background border-border focus-visible:border-primary"
            />
          </div>

          <div className="flex justify-end gap-2 pt-4 border-t border-border">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="rounded-none">
              Cancel
            </Button>
            <Button type="submit" disabled={updateMutation.isPending} className="rounded-none font-sans text-lg">
              {updateMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}