import { type LeaderboardEntry } from "@workspace/api-client-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { formatDistanceToNow } from "date-fns";

export function PlayerRow({ player }: { player: LeaderboardEntry }) {
  const isTop3 = player.rank <= 3;
  
  return (
    <div 
      className={`group relative grid grid-cols-1 lg:grid-cols-12 gap-4 items-center p-4 bg-card border transition-all duration-300
        ${isTop3 ? 'border-primary/50 shadow-[0_0_15px_rgba(255,60,0,0.1)]' : 'border-border hover:border-primary/30'}`}
    >
      {/* Rank */}
      <div className="col-span-1 flex items-center justify-between lg:justify-center">
        <span className="lg:hidden text-xs text-muted-foreground">Rank</span>
        <span className={`text-3xl font-sans font-bold ${
          player.rank === 1 ? 'text-[#FFD700] drop-shadow-[0_0_10px_rgba(255,215,0,0.5)]' :
          player.rank === 2 ? 'text-[#C0C0C0]' :
          player.rank === 3 ? 'text-[#CD7F32]' : 'text-muted-foreground'
        }`}>
          #{player.rank}
        </span>
      </div>

      {/* Player Info */}
      <div className="col-span-3 flex items-center gap-4">
        <Avatar className={`h-12 w-12 border-2 ${isTop3 ? 'border-primary' : 'border-border'}`}>
          <AvatarImage src={player.avatarUrl || undefined} alt={player.displayName} />
          <AvatarFallback className="bg-muted text-muted-foreground text-xl font-sans font-bold">
            {player.displayName.substring(0, 2).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="text-xl font-sans font-bold text-foreground">{player.displayName}</span>
            {player.robloxId && (
              <span className="text-xs text-muted-foreground">@{player.username}</span>
            )}
          </div>
          {player.note && (
            <Badge variant="outline" className="w-fit text-[10px] mt-1 bg-primary/10 text-primary border-primary/20 rounded-none">
              {player.note}
            </Badge>
          )}
        </div>
      </div>

      {/* Stats - Grid layout on mobile */}
      <div className="col-span-1 lg:col-span-7 grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-y-4 lg:gap-0 mt-4 lg:mt-0">
        <div className="flex flex-col lg:items-end">
          <span className="text-[10px] text-muted-foreground lg:hidden">Level</span>
          <span className="text-lg font-bold text-primary">{player.level ?? "-"}</span>
        </div>
        
        <div className="flex flex-col lg:items-end">
          <span className="text-[10px] text-muted-foreground lg:hidden">Kills</span>
          <span className="text-lg font-bold text-foreground">{player.kills ?? 0}</span>
        </div>
        
        <div className="flex flex-col lg:items-end">
          <span className="text-[10px] text-muted-foreground lg:hidden">Deaths</span>
          <span className="text-lg font-bold text-muted-foreground">{player.deaths ?? 0}</span>
        </div>
        
        <div className="flex flex-col lg:items-end">
          <span className="text-[10px] text-muted-foreground lg:hidden">KDR</span>
          <span className={`text-xl font-sans font-bold ${
            (player.kdr ?? 0) >= 2.0 ? 'text-primary drop-shadow-[0_0_5px_rgba(255,60,0,0.5)]' :
            (player.kdr ?? 0) >= 1.0 ? 'text-foreground' : 'text-muted-foreground'
          }`}>
            {player.kdr ? player.kdr.toFixed(2) : "0.00"}
          </span>
        </div>

        <div className="flex flex-col lg:items-end">
          <span className="text-[10px] text-muted-foreground lg:hidden">Wins</span>
          <span className="text-lg font-bold text-foreground">{player.wins ?? 0}</span>
        </div>

        <div className="flex flex-col lg:items-end">
          <span className="text-[10px] text-muted-foreground lg:hidden">Losses</span>
          <span className="text-lg font-bold text-muted-foreground">{player.losses ?? 0}</span>
        </div>

        <div className="flex flex-col lg:items-end">
          <span className="text-[10px] text-muted-foreground lg:hidden">W/S</span>
          <span className="text-lg font-bold text-foreground">{player.winStreak ?? 0}</span>
        </div>
      </div>
      
      {/* Last Synced */}
      <div className="col-span-1 flex items-center justify-start lg:justify-end text-[10px] text-muted-foreground/60 pt-2 lg:pt-0 border-t border-border/30 lg:border-none">
        {player.lastSyncedAt ? formatDistanceToNow(new Date(player.lastSyncedAt), { addSuffix: true }) : 'Never synced'}
      </div>
    </div>
  );
}