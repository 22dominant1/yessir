import { useGetLeaderboard, useGetLeaderboardStats } from "@workspace/api-client-react";
import { StatsHeader } from "@/components/stats-header";
import { PlayerRow } from "@/components/player-row";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

export default function Home() {
  const { data: leaderboard, isLoading: isLeaderboardLoading } = useGetLeaderboard();
  const { data: stats, isLoading: isStatsLoading } = useGetLeaderboardStats();

  return (
    <div className="min-h-[100dvh] w-full flex flex-col items-center bg-background text-foreground py-10 px-4 sm:px-8">
      <div className="w-full max-w-6xl flex flex-col gap-8">
        
        {/* Header Section */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b-2 border-primary pb-6">
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <h1 className="text-5xl md:text-7xl font-sans font-bold text-primary tracking-widest drop-shadow-[0_0_15px_rgba(255,60,0,0.5)]">
              Hoplex
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground tracking-[0.2em]">
              Official PvP Leaderboard
            </p>
          </div>
          
          <Link href="/admin" className="text-xs text-muted-foreground hover:text-primary transition-colors border border-border px-3 py-1 hover:border-primary">
            Admin Access
          </Link>
        </div>

        {/* Stats Strip */}
        {isStatsLoading ? (
          <Skeleton className="w-full h-24 bg-card/50 border border-border" />
        ) : (
          stats && <StatsHeader stats={stats} />
        )}

        {/* Leaderboard Table/List */}
        <div className="flex flex-col gap-3">
          <div className="grid grid-cols-12 gap-4 px-4 py-2 text-xs text-muted-foreground border-b border-border/50 uppercase tracking-wider hidden lg:grid">
            <div className="col-span-1 text-center">Rank</div>
            <div className="col-span-3">Player</div>
            <div className="col-span-1 text-right">Level</div>
            <div className="col-span-1 text-right">Kills</div>
            <div className="col-span-1 text-right">Deaths</div>
            <div className="col-span-1 text-right">KDR</div>
            <div className="col-span-1 text-right">Wins</div>
            <div className="col-span-1 text-right">Losses</div>
            <div className="col-span-1 text-right">W/S</div>
            <div className="col-span-1 text-right">Sync</div>
          </div>

          {isLeaderboardLoading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="w-full h-20 bg-card/30 border border-border" />
            ))
          ) : leaderboard?.length === 0 ? (
            <div className="py-12 text-center text-muted-foreground border border-dashed border-border bg-card/10">
              No warriors on the battlefield yet.
            </div>
          ) : (
            leaderboard?.map((player) => (
              <PlayerRow key={player.id} player={player} />
            ))
          )}
        </div>
        
      </div>
    </div>
  );
}