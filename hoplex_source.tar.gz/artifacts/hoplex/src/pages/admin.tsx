import { useState } from "react";
import { useGetLeaderboard, useSyncAllStats, getGetLeaderboardQueryKey, getGetLeaderboardStatsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Link } from "wouter";
import { Swords, RefreshCw } from "lucide-react";
import { AdminPlayerRow } from "@/components/admin-player-row";
import { AddPlayerDialog } from "@/components/add-player-dialog";
import { useToast } from "@/hooks/use-toast";

export default function Admin() {
  const [password, setPassword] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return localStorage.getItem("hoplex_admin_auth") === "true";
  });

  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: leaderboard, isLoading } = useGetLeaderboard();
  const syncAllMutation = useSyncAllStats();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === "hoplex2025") {
      localStorage.setItem("hoplex_admin_auth", "true");
      setIsAuthenticated(true);
    } else {
      alert("Invalid password");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("hoplex_admin_auth");
    setIsAuthenticated(false);
  };

  const handleSyncAll = () => {
    syncAllMutation.mutate(undefined, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetLeaderboardQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetLeaderboardStatsQueryKey() });
        toast({ title: "Global Sync Complete", description: "All stats synced." });
      },
      onError: (err) => {
        toast({ variant: "destructive", title: "Error", description: "Failed to sync all stats." });
      }
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-[100dvh] w-full flex items-center justify-center bg-background p-4">
        <form onSubmit={handleLogin} className="w-full max-w-sm flex flex-col gap-6 bg-card p-8 border border-border shadow-[0_0_30px_rgba(255,60,0,0.1)]">
          <div className="flex flex-col items-center text-center gap-2">
            <Swords className="w-12 h-12 text-primary mb-2" />
            <h1 className="text-4xl font-sans font-bold text-foreground uppercase tracking-widest">Admin Access</h1>
            <p className="text-sm text-muted-foreground">Authorized personnel only</p>
          </div>
          
          <div className="flex flex-col gap-2">
            <Input 
              type="password" 
              placeholder="Enter passcode..." 
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-background border-border focus-visible:border-primary text-center tracking-widest"
            />
          </div>
          
          <Button type="submit" className="w-full rounded-none font-sans text-xl tracking-wider">
            Authorize
          </Button>
          
          <Link href="/" className="text-center text-xs text-muted-foreground hover:text-primary mt-4">
            Return to Leaderboard
          </Link>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-[100dvh] w-full bg-background text-foreground py-10 px-4 sm:px-8">
      <div className="w-full max-w-5xl mx-auto flex flex-col gap-8">
        
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-border pb-6">
          <div className="flex flex-col items-center md:items-start text-center md:text-left">
            <h1 className="text-4xl font-sans font-bold text-foreground tracking-widest">
              War Room
            </h1>
            <p className="text-sm text-muted-foreground uppercase tracking-[0.2em]">
              Leaderboard Management
            </p>
          </div>
          
          <div className="flex flex-wrap items-center gap-4 justify-center md:justify-end">
            <Button 
              variant="outline" 
              onClick={handleSyncAll} 
              disabled={syncAllMutation.isPending}
              className="rounded-none border-primary text-primary hover:bg-primary hover:text-primary-foreground font-sans tracking-wide"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${syncAllMutation.isPending ? "animate-spin" : ""}`} />
              Sync All
            </Button>
            <AddPlayerDialog />
            <Button variant="outline" onClick={handleLogout} className="rounded-none border-border hover:bg-destructive hover:text-destructive-foreground hover:border-destructive">
              Lock Terminal
            </Button>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          {isLoading ? (
            <div className="text-center text-muted-foreground py-8">Loading data...</div>
          ) : leaderboard?.length === 0 ? (
            <div className="text-center text-muted-foreground py-8 border border-dashed border-border bg-card/50">
              No players found. Add someone to start the war.
            </div>
          ) : (
            leaderboard?.map((player) => (
              <AdminPlayerRow key={player.id} player={player} />
            ))
          )}
        </div>
      </div>
    </div>
  );
}