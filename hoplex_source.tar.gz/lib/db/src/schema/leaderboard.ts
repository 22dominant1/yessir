import { pgTable, text, serial, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const leaderboardTable = pgTable("leaderboard", {
  id: serial("id").primaryKey(),
  rank: integer("rank").notNull().default(0),
  score: real("score").notNull().default(0),
  username: text("username").notNull().unique(),
  robloxId: text("roblox_id"),
  displayName: text("display_name").notNull(),
  avatarUrl: text("avatar_url"),
  note: text("note"),
  kills: integer("kills"),
  deaths: integer("deaths"),
  wins: integer("wins"),
  losses: integer("losses"),
  kdr: real("kdr"),
  level: integer("level"),
  gamesPlayed: integer("games_played"),
  winStreak: integer("win_streak"),
  highestKillstreak: integer("highest_killstreak"),
  playtime: integer("playtime"),
  lastSyncedAt: timestamp("last_synced_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertLeaderboardSchema = createInsertSchema(leaderboardTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertLeaderboard = z.infer<typeof insertLeaderboardSchema>;
export type LeaderboardEntry = typeof leaderboardTable.$inferSelect;
